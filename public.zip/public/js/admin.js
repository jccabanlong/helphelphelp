$(document).ready(function(){
<<<<<<< HEAD
     $('.edit-trigger').click(function(){
        $('#edit-modal').modal('show');    
=======
     $('#add-user').click(function(){
        $('#add-modal').modal('show');    
>>>>>>> ee757fecd8e4cb9bd90e79891846a3f56d1d8dc4
     });
     $('#cancel').click(function(){
        $('#edit-modal').modal('hide');    
     });
<<<<<<< HEAD
       $('.delete-trigger').click(function(){
        $('#delete-modal').modal('show');    
     });
=======
     $('#delete').click(function(){
        $('#delete-modal').modal('show');    
     });
     $('.edit-trigger').click(function(){
        $('#edit-modal').modal('show');    
     });
>>>>>>> ee757fecd8e4cb9bd90e79891846a3f56d1d8dc4
});
