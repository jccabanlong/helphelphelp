$(document).ready(function(){
<<<<<<< HEAD
     $('#add-user').click(function(){
        $('#add-modal').modal('show');    
     });
     $('#cancel').click(function(){
        $('#edit-modal').modal('hide');    
     });
     $('#delete').click(function(){
        $('#delete-modal').modal('show');    
     });
     $('.edit-trigger').click(function(){
        $('#edit-modal').modal('show');    
     });
});
=======
     $('.edit-trigger').click(function(){
        $('#edit-modal').modal('show');
            
     });

     $('.delete-trigger').click(function(){
        $('#delete-modal').modal('show');    
     });

     $('.add-trigger').click(function(){
     	$('#add-modal').modal('show');
     });



});
>>>>>>> 7543b5786efb4d4173894087fbb83cfe41b06f1d
