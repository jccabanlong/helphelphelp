'use strict';

(function() {
	angular.module('malicsi', ['ngRoute']);
})();
